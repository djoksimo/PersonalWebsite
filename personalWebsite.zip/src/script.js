// JavaScript source code

/*change link colors on hover*/
/*active page*/

//add animations